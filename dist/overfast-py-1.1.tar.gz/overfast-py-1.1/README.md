# overfast-py
TeKrop's OverFast API in Python.
Made by Amemoia.

# Installation
Windows
`py -m pip install overfast-py`